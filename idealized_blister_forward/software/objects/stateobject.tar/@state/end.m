function s=end(x,k,n)
%
%end function for state objects

s=size(x);
s=s(1);