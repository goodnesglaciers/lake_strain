function s=size(x)
%
%Size function for state objects

s=size(x.index)-1;